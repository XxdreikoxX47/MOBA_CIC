import pygame
from pygame.sprite import Group, Sprite
import constante_1
import math
import random
import time


class Weapon(): # ✅ NO hereda de Sprite para mantener la lógica original de tu Weapon
    def __init__(self, image, imagen_BLuz):
        self.imagen_BLuz = imagen_BLuz
        self.imagen_original = image
        self.angulo = 0
        self.image = pygame.transform.rotate(
            self.imagen_original, self.angulo)
        # ✅ Usamos 'rect' para la Weapon porque es para la rotación y el blit.
        # NO es el rect de colisión del arma en el mundo, sino para su dibujado.
        self.rect = self.image.get_rect()
        self.dispara = False
        self.ultimo_disparo = pygame.time.get_ticks()
        self.incremento_dano = 1 # Variable para controlar el aumento del daño

    # ✅ MODIFICACIÓN: Ya NO retorna BLuz. Solo actualiza la posición y rotación del báculo.
    def update(self, personaje):
        # La posición del báculo se centra en el personaje y se ajusta por offsets.
        # personaje.forma.center es la posición del personaje en el mundo.
        self.rect.center = personaje.forma.center

        # Ajustes de posición para el báculo relativos al personaje
        # Estos valores pueden necesitar ajuste fino para que el báculo se vea bien.
        if personaje.flip == False: # Personaje mirando a la derecha
            self.rect.x += personaje.forma.width / 2.1 # Mover a la derecha del personaje
            self.rect.y += -0.3 # Ligeramente hacia arriba
        if personaje.flip == True: # Personaje mirando a la izquierda
            self.rect.x -= personaje.forma.width / 2.1 # Mover a la izquierda del personaje
            self.rect.y += -0.3 # Ligeramente hacia arriba

        # Mover Baculo con Mause
        mouse_x_screen, mouse_y_screen = pygame.mouse.get_pos()

        # Convertir la posición del báculo en pantalla para calcular el ángulo con el mouse
        # Esto asume que el báculo ya está en la posición correcta de la pantalla.
        # Si el báculo debe apuntar al mouse en coordenadas de pantalla, entonces se usa la posición del báculo en pantalla.
        # Si debe apuntar a la posición del mouse en el mundo, sería más complejo aquí.
        # Asumimos que apunta al mouse en pantalla para la rotación visual.
        distancia_x = mouse_x_screen - (self.rect.centerx) # No restamos scroll aquí porque el mouse_pos ya es screen_pos
        distancia_y = mouse_y_screen - (self.rect.centery)

        self.angulo = math.degrees(math.atan2(-distancia_y, distancia_x)) # Calcula el ángulo para la rotación visual

        # Rotar el arma
        self.image = pygame.transform.rotate(self.imagen_original, self.angulo)
        # Recalcula el rect después de la rotación para mantenerlo centrado en su posición anterior
        self.rect = self.image.get_rect(center=self.rect.center)


    # ✅ MODIFICACIÓN: Añade bg_scroll_x y bg_scroll_y para dibujar
    def dibujar(self, ventana, bg_scroll_x=0, bg_scroll_y=0):
        # Dibuja el arma ajustada por el scroll
        # El self.rect.x y self.rect.y son las coordenadas del báculo en el mundo (relativas al jugador)
        # Por lo tanto, se ajustan por el scroll para dibujarse en pantalla.
        ventana.blit(self.image, (self.rect.x - bg_scroll_x, self.rect.y - bg_scroll_y))


# ✅ MODIFICACIÓN: Todas las clases de proyectiles deben heredar de Sprite
class BLuz(Sprite):
    def __init__(self, image, x_world, y_world, angle):
        super().__init__()
        # ✅ CRÍTICO: Manejo de imagen faltante
        if image:
            self.image_original = image
        else:
            print("Advertencia: Imagen para BLuz no proporcionada. Usando placeholder.")
            self.image_original = pygame.Surface((10, 10), pygame.SRCALPHA)
            pygame.draw.circle(self.image_original, (0, 255, 255, 128), (5, 5), 5) # Círculo semitransparente

        self.image = pygame.transform.rotate(self.image_original, angle)
        # ✅ CRÍTICO: self.rect es la posición del proyectil en el MUNDO
        self.rect = self.image.get_rect(center=(x_world, y_world))
        self.speed = constante_1.VELOCIDAD_BLuz
        self.angle_rad = math.radians(angle) # Convertir a radianes
        self.dx = math.cos(self.angle_rad) * self.speed
        self.dy = -math.sin(self.angle_rad) * self.speed # Negativo porque y aumenta hacia abajo
        self.damage = 10 # Daño base
        self.time_created = pygame.time.get_ticks()
        self.duration = 2000 # Duración del proyectil en milisegundos (2 segundos)

    def update(self):
        # ✅ CRÍTICO: Mueve el rectángulo directamente en coordenadas del mundo
        self.rect.x += self.dx
        self.rect.y += self.dy

        # Eliminar el proyectil si ha excedido su duración
        if pygame.time.get_ticks() - self.time_created > self.duration:
            self.kill() # Elimina el sprite del grupo

    # ✅ MODIFICACIÓN: El método dibujar se encargará del scroll
    def dibujar(self, ventana, bg_scroll_x=0, bg_scroll_y=0):
        # Dibuja el proyectil ajustado por el scroll
        ventana.blit(self.image, (self.rect.x - bg_scroll_x, self.rect.y - bg_scroll_y))


class Explosion(Sprite): # Hereda de Sprite
    def __init__(self, image, x_world, y_world): # ✅ Removido damage_multiplier del constructor
        super().__init__()
        # ✅ CRÍTICO: Manejo de imagen faltante
        if image:
            self.image = image
        else:
            print("Advertencia: Imagen para Explosion no proporcionada. Usando placeholder.")
            self.image = pygame.Surface((50,50), pygame.SRCALPHA)
            pygame.draw.circle(self.image, (255, 100, 0, 128), (25,25), 25)

        # ✅ CRÍTICO: self.rect es la posición de la explosión en el MUNDO
        self.rect = self.image.get_rect(center=(x_world, y_world))
        self.damage = 25 # Daño base, no multiplicado aquí, sino constante_1.DAÑO_EXPLOSION
        self.time_created = pygame.time.get_ticks()
        self.time_vida = 500 # Duración de la explosión en ms (0.5 segundos)
        self.daño_infligido = False # Para asegurar que el daño se aplique solo una vez

    def update(self, lista_enemigos, torre):
        tiempo_actual = pygame.time.get_ticks()
        if tiempo_actual - self.time_created > self.time_vida:
            self.kill() # Elimina la explosión después de su duración
            return 0, None # Retorna 0 daño y None posición

        # Aplicar daño solo una vez
        if not self.daño_infligido:
            # Colisión con la torre
            # ✅ Colisión con torre.forma (rectángulo de colisión del personaje en el mundo)
            if self.rect.colliderect(torre.forma):
                torre.energia -= self.damage
                self.daño_infligido = True
                print(f"Explosión impactó la torre con {self.damage} daño.")
                return self.damage, torre.forma.center # Retorna daño y la posición del centro de la forma de la torre

            # Colisión con enemigos
            for enemigo in lista_enemigos:
                # ✅ Colisión con enemigo.forma
                if enemigo.vivo and self.rect.colliderect(enemigo.forma):
                    enemigo.energia -= self.damage
                    self.daño_infligido = True
                    print(f"Explosión impactó a enemigo con {self.damage} daño.")
                    return self.damage, enemigo.forma.center # Retorna daño y la posición del centro de la forma del enemigo
        return 0, None # No hay daño si ya se infligió o no hay colisión

    # ✅ MODIFICACIÓN: El método dibujar se encargará del scroll
    def dibujar(self, ventana, bg_scroll_x=0, bg_scroll_y=0):
        # Dibuja la explosión ajustada por el scroll
        ventana.blit(self.image, (self.rect.x - bg_scroll_x, self.rect.y - bg_scroll_y))


class AtaEsp22(Sprite): # Hereda de Sprite
    ultimo_uso = 0 # Variable de clase para enfriamiento

    def __init__(self, image, x_world, y_world, direccion):
        super().__init__()
        # ✅ CRÍTICO: Manejo de imagen faltante
        if image:
            self.image_original = image
        else:
            print("Advertencia: Imagen para AtaEsp22 no proporcionada. Usando placeholder.")
            self.image_original = pygame.Surface((50,50), pygame.SRCALPHA)
            pygame.draw.circle(self.image_original, (150, 0, 150, 128), (25,25), 25)

        # Calcular ángulo para rotar la imagen
        dx, dy = direccion
        self.angle = math.degrees(math.atan2(-dy, dx)) # Ángulo para apuntar
        self.image = pygame.transform.rotate(self.image_original, self.angle)
        # ✅ CRÍTICO: self.rect es la posición del proyectil en el MUNDO
        self.rect = self.image.get_rect(center=(x_world, y_world))
        self.velocidad = constante_1.VELOCIDAD_ATA_ESP22
        self.daño_base = constante_1.DAÑO_BASE_ATA_ESP22
        self.tiempo_inicio = pygame.time.get_ticks()
        self.duracion = constante_1.DURACION_ATA_ESP22 * 1000 # Convertir segundos a milisegundos
        self.daño_registrado = False # Para asegurar que el daño se aplique solo una vez por impacto

        distancia = math.sqrt(dx**2 + dy**2)
        if distancia == 0: # ✅ Evitar división por cero
            self.direccion_x = 0
            self.direccion_y = 0
        else:
            self.direccion_x = (dx / distancia) * self.velocidad
            self.direccion_y = (dy / distancia) * self.velocidad

    @classmethod
    def puede_usarse(cls):
        return (pygame.time.get_ticks() - cls.ultimo_uso) > constante_1.TIEMPO_ENFRIAMIENTO_ATA_ESP22 * 1000

    @classmethod
    def registrar_uso(cls):
        cls.ultimo_uso = pygame.time.get_ticks()

    def update(self, lista_enemigos, torre):
        tiempo_actual = pygame.time.get_ticks()

        if tiempo_actual - self.tiempo_inicio > self.duracion:
            self.kill()
            return 0, None

        # ✅ CRÍTICO: Mueve el rectángulo directamente en coordenadas del mundo
        self.rect.x += self.direccion_x
        self.rect.y += self.direccion_y

        # Verificar colisión con enemigos y la torre
        # Iterar sobre una copia de la lista de enemigos para evitar problemas si se eliminan
        for enemigo in lista_enemigos[:] + [torre]:
            # ✅ Colisión con enemigo.forma y verificar si está vivo
            if enemigo.vivo and self.rect.colliderect(enemigo.forma):
                if not self.daño_registrado:
                    daño = self.daño_base + random.randint(-10, 10)
                    enemigo.energia -= daño # ✅ Usar enemigo.energia
                    self.daño_registrado = True
                    self.kill()
                    return daño, enemigo.forma # Retorna daño y la forma del enemigo

        return 0, None

    # ✅ MODIFICACIÓN: El método dibujar se encargará del scroll
    def dibujar(self, ventana, bg_scroll_x=0, bg_scroll_y=0):
        # Dibuja el proyectil ajustado por el scroll
        ventana.blit(self.image, (self.rect.x - bg_scroll_x, self.rect.y - bg_scroll_y))


class AtaEspMAX(Sprite): # Hereda de Sprite
    ultimo_uso = 0 # Variable de clase para enfriamiento

    def __init__(self, image, x_world, y_world, direccion):
        super().__init__()
        # ✅ CRÍTICO: Manejo de imagen faltante
        if image:
            self.image_original = image
        else:
            print("Advertencia: Imagen para AtaEspMAX no proporcionada. Usando placeholder.")
            self.image_original = pygame.Surface((50,50), pygame.SRCALPHA)
            pygame.draw.circle(self.image_original, (255, 0, 0, 128), (25,25), 25)

        dx, dy = direccion
        self.angle = math.degrees(math.atan2(-dy, dx))
        self.image = pygame.transform.rotate(self.image_original, self.angle)
        # ✅ CRÍTICO: self.rect es la posición del proyectil en el MUNDO
        self.rect = self.image.get_rect(center=(x_world, y_world))
        self.velocidad = constante_1.VELOCIDAD_ATA_ESPMAX
        self.daño_base = constante_1.DAÑO_BASE_ATA_ESPMAX
        self.tiempo_inicio = pygame.time.get_ticks()
        self.duracion = constante_1.DURACION_ATA_ESPMAX * 1000 # Convertir segundos a milisegundos
        self.daño_registrado = False # Para asegurar que el daño se aplique solo una vez por impacto

        distancia = math.sqrt(dx**2 + dy**2)
        if distancia == 0: # ✅ Evitar división por cero
            self.direccion_x = 0
            self.direccion_y = 0
        else:
            self.direccion_x = (dx / distancia) * self.velocidad
            self.direccion_y = (dy / distancia) * self.velocidad

    @classmethod
    def puede_usarse(cls):
        return (pygame.time.get_ticks() - cls.ultimo_uso) > constante_1.TIEMPO_ENFRIAMIENTO_ATA_ESPMAX * 1000

    @classmethod
    def registrar_uso(cls):
        cls.ultimo_uso = pygame.time.get_ticks()

    def update(self, lista_enemigos, torre):
        tiempo_actual = pygame.time.get_ticks()

        if tiempo_actual - self.tiempo_inicio > self.duracion:
            self.kill()
            return 0, None

        # ✅ CRÍTICO: Mueve el rectángulo directamente en coordenadas del mundo
        self.rect.x += self.direccion_x
        self.rect.y += self.direccion_y

        # Verificar colisión con enemigos y la torre
        # Iterar sobre una copia de la lista de enemigos para evitar problemas si se eliminan
        for enemigo in lista_enemigos[:] + [torre]:
            # ✅ Colisión con enemigo.forma y verificar si está vivo
            if enemigo.vivo and self.rect.colliderect(enemigo.forma):
                if not self.daño_registrado:
                    daño = self.daño_base + random.randint(-10, 10) # No usas incremento_dano aquí, pero sí en weapon.txt
                    enemigo.energia -= daño # ✅ Usar enemigo.energia
                    self.daño_registrado = True
                    self.kill()
                    return daño, enemigo.forma # Retorna daño y la forma del enemigo
        return 0, None

    # ✅ MODIFICACIÓN: El método dibujar se encargará del scroll
    def dibujar(self, ventana, bg_scroll_x=0, bg_scroll_y=0):
        # Dibuja el proyectil ajustado por el scroll
        ventana.blit(self.image, (self.rect.x - bg_scroll_x, self.rect.y - bg_scroll_y))