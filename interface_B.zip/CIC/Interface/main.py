import pygame
import csv
import constante_1
from Personaje import Personaje
import objetos_test
import trainMOBAgents_quasi
from weapon import Weapon
from weapon import Explosion
from weapon import AtaEsp22
from weapon import AtaEspMAX
from Menus import MenuCargaUsuario, MenuCargar, MenuRegistro, MenuDificultad, MenuPausa
# Importar la función de carga de pantalla
from PantallaCarga import pantalla_de_carga
import os
from Textos import DamageText
import time
import AvatarAtacante
import random
import math
import Menus

# ------------------------- Pasar a constantes ---------------------------

# Dimensiones del mapa
MAP_WIDTH = 5000
MAP_HEIGHT = 5000

# Variables del ataque especial
ataque_especial = False
tiempo_ultimo_ataque_especial = 0
TIEMPO_ENFIRAMIENTO = 90  # 1 minuto y 30 segundos
DURACION_ATAQUE_ESPECIAL = 5  # Duración del ataque especial en segundos


ataque_explosion_activo = False
ataque_explosion_timer = 0
DURACION_ATAQUE_EXPLOSION = 3  # Duración del ataque de explosión en segundos
# Tiempo de enfriamiento para el ataque de explosión en segundos
TIEMPO_ENFRIAMIENTO_EXPLOSION = 5
tiempo_ultimo_ataque_explosion = 0


ataque_basico_activo = False
ataque_basico_timer = 0
DURACION_ATAQUE_BASICO = 1
TIEMPO_ENFRIAMIENTO_BASICO = 1
tiempo_ultimo_ataque_basico = 0

ataque_especial_basico1_activo = False
ataque_especial_basico1_timer = 0
DURACION_ATAQUE_ESPECIAL_BASICO1 = 1
TIEMPO_ENFRIAMIENTO_ESPECIAL_BASICO1 = 1
tiempo_ultimo_ataque_especial_basico1 = 0

ataque_especial_basico2_activo = False
ataque_especial_basico2_timer = 0
DURACION_ATAQUE_ESPECIAL_BASICO2 = 1
TIEMPO_ENFRIAMIENTO_ESPECIAL_BASICO2 = 1
tiempo_ultimo_ataque_especial_basico2 = 0


# Inicializar Pygame
pygame.init()

# ------------------------- CONFIGURACIÓN DE PANTALLA -------------------------
VENTANA = pygame.display.set_mode(
    (constante_1.ANCHO_VENTANA, constante_1.ALTO_VENTANA))
pygame.display.set_caption("MOBA CSCOG")
icono = pygame.image.load("assets/images/icons/icon.png")
pygame.display.set_icon(icono)

# ------------------------- Cargar imágenes -------------------------
fondo_img = pygame.image.load(
    "assets/images/Escenarios/Fondo_pasto.png").convert_alpha()
player_animaciones = []
for i in range(2):
    img = pygame.image.load(f"assets/images/characters/Player/player_{i}.png")
    player_animaciones.append(img)

# Cargar imagen del arma
BLuz_imagen = pygame.image.load("assets/images/Weaponds/BLuz.png").convert_alpha()
Magico_imagen = pygame.image.load("assets/images/Weaponds/Magico_0.png").convert_alpha()
ataqueEspecial21_img = pygame.image.load(
    "assets/images/Weaponds/FireBool_2_1.png").convert_alpha()
ataqueEspecial11_img = pygame.image.load(
    "assets/images/Weaponds/BolaMorada.png").convert_alpha()
ataqueEspecialMAX_img = pygame.image.load(
    "assets/images/Weaponds/FireboolRed.png").convert_alpha()

# Cargar imagen de las explosiones
explosion_img = pygame.image.load(
    "assets/images/particles/explosion.png").convert_alpha()

# Fuentes
font = pygame.font.Font("assets/fonts/AtariClassic.ttf", 20)
font_damage = pygame.font.Font("assets/fonts/AtariClassic.ttf", 20)


# Función para dibujar texto
def dibujar_texto(texto, fuente, color, x, y):
    img = fuente.render(texto, True, color)
    VENTANA.blit(img, (x, y))


# ------------------------- Grupos de Sprites -------------------------
grupo_proyectiles = pygame.sprite.Group()
grupo_explosiones = pygame.sprite.Group()
grupo_ata_esp22 = pygame.sprite.Group()
grupo_ata_espMAX = pygame.sprite.Group()
grupo_texto_daño = pygame.sprite.Group()

# ------------------------- Instancias -------------------------
jugador = Personaje(
    constante_1.ANCHO_VENTANA // 2,
    constante_1.ALTO_VENTANA // 2,
    player_animaciones,
    100,
    1,
)  # Tipo 1 para el jugador
arma_jugador = Weapon(Magico_imagen, BLuz_imagen)
avatar_enemigo = AvatarAtacante.AvatarAtacante(
    player_animaciones, 50, 2
)  # Tipo 2 para el enemigo
torre_defensa = objetos_test.Torre(
    constante_1.ANCHO_VENTANA - 100, constante_1.ALTO_VENTANA - 100, 200
)

# ------------------------- Variables de juego -------------------------
pausado = False
menu_principal_activo = True
menu_carga_usuario_activo = False
menu_registro_activo = False
menu_dificultad_activo = False
menu_cargar_activo = False
juego_iniciado = False
nombre_usuario_actual = ""

# ------------------------- Menús -------------------------
menu_principal = Menus.MenuPrin(VENTANA)
menu_carga_usuario = MenuCargaUsuario(VENTANA)
menu_registro = MenuRegistro(VENTANA)
menu_dificultad = MenuDificultad(VENTANA)
menu_cargar = MenuCargar(VENTANA)
menu_pausa = MenuPausa(VENTANA)


# ------------------------- Bucle del juego -------------------------
corriendo = True
clock = pygame.time.Clock()

# ✅ Variables para el scrolling
bg_scroll_x = 0
bg_scroll_y = 0

def dibujar_grid():
    grid_size = 50
    # Dibujar solo las líneas que son visibles en la ventana actual
    start_x = max(0, bg_scroll_x - (bg_scroll_x % grid_size))
    end_x = min(MAP_WIDTH, bg_scroll_x + constante_1.ANCHO_VENTANA + (grid_size - (bg_scroll_x % grid_size)))
    start_y = max(0, bg_scroll_y - (bg_scroll_y % grid_size))
    end_y = min(MAP_HEIGHT, bg_scroll_y + constante_1.ALTO_VENTANA + (grid_size - (bg_scroll_y % grid_size)))


    for x in range(start_x, end_x, grid_size):
        pygame.draw.line(VENTANA, constante_1.WHITE, (x - bg_scroll_x, 0), (x - bg_scroll_x, constante_1.ALTO_VENTANA))
    for y in range(start_y, end_y, grid_size):
        pygame.draw.line(VENTANA, constante_1.WHITE, (0, y - bg_scroll_y), (constante_1.ANCHO_VENTANA, y - bg_scroll_y))


# ✅ Función para dibujar el fondo con scrolling
def dibujar_fondo(ventana, bg_img, bg_scroll_x, bg_scroll_y):
    # Calcula cuántas veces necesitas blitear la imagen para cubrir la pantalla
    # Asegúrate de que el fondo se repita en ambos ejes
    img_width = bg_img.get_width()
    img_height = bg_img.get_height()

    # Calcular el offset inicial para que el fondo se alinee correctamente con el scroll
    offset_x = bg_scroll_x % img_width
    offset_y = bg_scroll_y % img_height

    for x in range(-offset_x, constante_1.ANCHO_VENTANA, img_width):
        for y in range(-offset_y, constante_1.ALTO_VENTANA, img_height):
            ventana.blit(bg_img, (x, y))


while corriendo:
    clock.tick(constante_1.FPS)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            corriendo = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                pausado = not pausado
        if menu_principal_activo:
            resultado_menu_principal = menu_principal.manejar_eventos(event)
            if resultado_menu_principal == "Iniciar Juego":
                menu_principal_activo = False
                menu_carga_usuario_activo = True
            elif resultado_menu_principal == "Salir":
                corriendo = False
        elif menu_carga_usuario_activo:
            resultado_carga = menu_carga_usuario.manejar_eventos(event)
            if resultado_carga == "confirmar":
                nombre_usuario_actual = menu_carga_usuario.get_nombre_usuario()
                menu_carga_usuario_activo = False
                menu_cargar_activo = True  # Pasa al menú de cargar partida
            elif resultado_carga == "registrar":
                menu_carga_usuario_activo = False
                menu_registro_activo = True
            elif resultado_carga == "atras":
                menu_carga_usuario_activo = False
                menu_principal_activo = True
        elif menu_registro_activo:
            resultado_registro = menu_registro.manejar_eventos(event)
            if resultado_registro == "registrado":
                nombre_usuario_actual = menu_registro.get_nombre_usuario()
                menu_registro_activo = False
                menu_cargar_activo = True  # Pasa al menú de cargar partida
            elif resultado_registro == "atras":
                menu_registro_activo = False
                menu_carga_usuario_activo = True
        elif menu_cargar_activo:
            resultado_cargar = menu_cargar.manejar_eventos(event)
            if resultado_cargar == "iniciar":
                juego_iniciado = True
                menu_cargar_activo = False
            elif resultado_cargar == "atras":
                menu_cargar_activo = False
                menu_carga_usuario_activo = True
        elif menu_dificultad_activo:
            resultado_dificultad = menu_dificultad.manejar_eventos(event)
            if resultado_dificultad == "seleccionado":
                menu_dificultad_activo = False
                juego_iniciado = True  # Inicia el juego después de seleccionar dificultad
            elif resultado_dificultad == "atras":
                menu_dificultad_activo = False
                menu_cargar_activo = True  # Vuelve al menú de cargar partida
        elif juego_iniciado and pausado:
            resultado_pausa = menu_pausa.manejar_eventos(event)
            if resultado_pausa == "reanudar":
                pausado = False
            elif resultado_pausa == "salir":
                corriendo = False

    if juego_iniciado and not pausado:
        # Movimiento del jugador
        delta_x = 0
        delta_y = 0
        key = pygame.key.get_pressed()
        if key[pygame.K_a]:
            delta_x = -constante_1.VELOCIDAD_JUGADOR
        if key[pygame.K_d]:
            delta_x = constante_1.VELOCIDAD_JUGADOR
        if key[pygame.K_w]:
            delta_y = -constante_1.VELOCIDAD_JUGADOR
        if key[pygame.K_s]:
            delta_y = constante_1.VELOCIDAD_JUGADOR

        # ✅ Actualizar la posición del jugador en el mundo
        # El método movimiento ahora solo actualiza la posición del jugador (self.forma.x, self.forma.y)
        jugador.movimiento(delta_x, delta_y)

        # ✅ Calcular el offset del scroll en función de la posición del jugador
        # Centrar la cámara en el jugador
        bg_scroll_x = jugador.forma.centerx - (constante_1.ANCHO_VENTANA // 2)
        bg_scroll_y = jugador.forma.centery - (constante_1.ALTO_VENTANA // 2)

        # ✅ Limitar el scroll a los bordes del mapa
        bg_scroll_x = max(0, min(bg_scroll_x, MAP_WIDTH - constante_1.ANCHO_VENTANA))
        bg_scroll_y = max(0, min(bg_scroll_y, MAP_HEIGHT - constante_1.ALTO_VENTANA))


        # Ataque básico del jugador
        if pygame.mouse.get_pressed()[0] and pygame.time.get_ticks() - tiempo_ultimo_ataque_basico > TIEMPO_ENFRIAMIENTO_BASICO * 1000:
            ataque_basico_activo = True
            ataque_basico_timer = pygame.time.get_ticks()
            tiempo_ultimo_ataque_basico = pygame.time.get_ticks()

        # Ataque especial 1 del jugador
        if pygame.mouse.get_pressed()[2] and pygame.time.get_ticks() - tiempo_ultimo_ataque_especial_basico1 > TIEMPO_ENFRIAMIENTO_ESPECIAL_BASICO1 * 1000:
            ataque_especial_basico1_activo = True
            ataque_especial_basico1_timer = pygame.time.get_ticks()
            tiempo_ultimo_ataque_especial_basico1 = pygame.time.get_ticks()
            # Crear proyectil AtaEsp22
            proyectil_ata_esp22 = AtaEsp22(
                jugador.forma.centerx,
                jugador.forma.centery,
                ataqueEspecial21_img,
                80,
                jugador.flip,
            )
            grupo_ata_esp22.add(proyectil_ata_esp22)


        # Ataque especial MAX del jugador (Ejemplo, puedes cambiar la tecla)
        if key[pygame.K_q] and pygame.time.get_ticks() - tiempo_ultimo_ataque_especial > TIEMPO_ENFIRAMIENTO * 1000:
            ataque_especial = True
            tiempo_ultimo_ataque_especial = pygame.time.get_ticks()
            # Crear proyectil AtaEspMAX
            proyectil_ata_espMAX = AtaEspMAX(
                jugador.forma.centerx,
                jugador.forma.centery,
                ataqueEspecialMAX_img,
                200,
                jugador.flip,
            )
            grupo_ata_espMAX.add(proyectil_ata_espMAX)

        # Actualizar estado de los ataques
        tiempo_actual = pygame.time.get_ticks()
        if ataque_basico_activo and tiempo_actual - ataque_basico_timer > DURACION_ATAQUE_BASICO * 1000:
            ataque_basico_activo = False

        if ataque_especial_basico1_activo and tiempo_actual - ataque_especial_basico1_timer > DURACION_ATAQUE_ESPECIAL_BASICO1 * 1000:
            ataque_especial_basico1_activo = False

        if ataque_especial and tiempo_actual - tiempo_ultimo_ataque_especial > DURACION_ATAQUE_ESPECIAL * 1000:
            ataque_especial = False

        # Actualizar
        jugador.update()
        arma_jugador.update(jugador)
        avatar_enemigo.update()
        torre_defensa.update()

        # ✅ Actualizar y dibujar proyectiles y explosiones con scroll
        damage_text_data = []  # Para almacenar los datos de daño y crearlos al final del bucle

        for proyectil in grupo_proyectiles:
            daño, objetivo_dañado = proyectil.update([avatar_enemigo], torre_defensa)
            if daño > 0:
                if objetivo_dañado:
                    damage_text_data.append((objetivo_dañado.forma.centerx, objetivo_dañado.forma.centery, daño, font_damage, constante_1.RED))
                explosion = Explosion(proyectil.rect.centerx, proyectil.rect.centery, explosion_img)
                grupo_explosiones.add(explosion)

        for proyectil in grupo_ata_esp22:
            daño, objetivo_dañado = proyectil.update([avatar_enemigo], torre_defensa)
            if daño > 0:
                if objetivo_dañado:
                    damage_text_data.append((objetivo_dañado.forma.centerx, objetivo_dañado.forma.centery, daño, font_damage, constante_1.RED))
                explosion = Explosion(proyectil.rect.centerx, proyectil.rect.centery, explosion_img)
                grupo_explosiones.add(explosion)

        for proyectil in grupo_ata_espMAX:
            daño, objetivo_dañado = proyectil.update([avatar_enemigo], torre_defensa)
            if daño > 0:
                if objetivo_dañado:
                    damage_text_data.append((objetivo_dañado.forma.centerx, objetivo_dañado.forma.centery, daño, font_damage, constante_1.RED))
                explosion = Explosion(proyectil.rect.centerx, proyectil.rect.centery, explosion_img)
                grupo_explosiones.add(explosion)


        # Crear los objetos DamageText después de que todos los proyectiles hayan actualizado
        for x, y, damage, font, color in damage_text_data:
            # ✅ Ajustar la posición del texto de daño por el scroll
            grupo_texto_daño.add(DamageText(x - bg_scroll_x, y - bg_scroll_y, damage, font, color))


        grupo_explosiones.update()
        grupo_texto_daño.update()

        # Dibujar
        VENTANA.fill(constante_1.GREEN)
        # ✅ Dibujar el fondo con el offset del scroll
        dibujar_fondo(VENTANA, fondo_img, bg_scroll_x, bg_scroll_y)


        # ✅ Dibujar objetos con el offset del scroll
        arma_jugador.dibujar(VENTANA, bg_scroll_x, bg_scroll_y)
        avatar_enemigo.dibujar(VENTANA, bg_scroll_x, bg_scroll_y)
        torre_defensa.dibujar(VENTANA, bg_scroll_x, bg_scroll_y) # Asume que Torre tiene un método dibujar similar que acepta scroll

        for proyectil in grupo_proyectiles:
            proyectil.dibujar(VENTANA, bg_scroll_x, bg_scroll_y) # Asume que Proyectil tiene un método dibujar similar que acepta scroll
        for proyectil in grupo_ata_esp22:
            proyectil.dibujar(VENTANA, bg_scroll_x, bg_scroll_y) # Asume que AtaEsp22 tiene un método dibujar similar que acepta scroll
        for proyectil in grupo_ata_espMAX:
            proyectil.dibujar(VENTANA, bg_scroll_x, bg_scroll_y) # Asume que AtaEspMAX tiene un método dibujar similar que acepta scroll


        if ataque_basico_activo:
            # ✅ Ajustar la posición de ataqueEspecial21_img por el scroll
            VENTANA.blit(
                ataqueEspecial21_img,
                (jugador.forma.centerx - ataqueEspecial21_img.get_width() // 2 - bg_scroll_x,
                 jugador.forma.centery - ataqueEspecial21_img.get_height() // 2 - bg_scroll_y)
            )

        if ataque_especial_basico1_activo:
            # ✅ Ajustar la posición de ataqueEspecial11_img por el scroll
            VENTANA.blit(
                ataqueEspecial11_img,
                (jugador.forma.centerx - ataqueEspecial11_img.get_width() // 2 - bg_scroll_x,
                 jugador.forma.centery - ataqueEspecial11_img.get_height() // 2 - bg_scroll_y)
            )

        for explosion in grupo_explosiones:
            explosion.dibujar(VENTANA, bg_scroll_x, bg_scroll_y) # Asume que Explosion tiene un método dibujar similar que acepta scroll

        jugador.dibujar(VENTANA, bg_scroll_x, bg_scroll_y)
        dibujar_grid() # La grilla también se verá afectada por el scroll

        # Dibujar textos de daño
        grupo_texto_daño.draw(VENTANA)


        dibujar_texto(
            f"VIDA JUGADOR: {jugador.vida}",
            font,
            constante_1.WHITE,
            10,
            10,
        )
        dibujar_texto(
            f"ENERGIA JUGADOR: {jugador.energia}",
            font,
            constante_1.WHITE,
            10,
            40,
        )
        dibujar_texto(
            f"VIDA TORRE: {torre_defensa.vida}",
            font,
            constante_1.WHITE,
            10,
            70,
        )
        dibujar_texto(
            f"FPS: {int(clock.get_fps())}",
            font,
            constante_1.WHITE,
            constante_1.ANCHO_VENTANA - 100,
            10,
        )
        dibujar_texto(
            f"Jugador X: {jugador.forma.x}",
            font,
            constante_1.WHITE,
            constante_1.ANCHO_VENTANA - 200,
            40,
        )
        dibujar_texto(
            f"Jugador Y: {jugador.forma.y}",
            font,
            constante_1.WHITE,
            constante_1.ANCHO_VENTANA - 200,
            70,
        )


    elif menu_principal_activo:
        menu_principal.dibujar()
    elif menu_carga_usuario_activo:
        menu_carga_usuario.dibujar()
    elif menu_registro_activo:
        menu_registro.dibujar()
    elif menu_cargar_activo:
        menu_cargar.dibujar()
    elif menu_dificultad_activo:
        menu_dificultad.dibujar()
    elif juego_iniciado and pausado:
        menu_pausa.dibujar()
        # Manejar eventos del menú de pausa
        pygame.display.flip()
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            resultado_pausa = menu_pausa.manejar_eventos(event)
            if resultado_pausa == "reanudar":
                pausado = False
            elif resultado_pausa == "salir":
                corriendo = False

    pygame.display.flip()


pygame.quit()